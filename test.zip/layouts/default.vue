<template>
  <div class="max-w-full mx-auto bg-text-light">
    <slot/>
  </div>
</template>

<style scoped>

</style>