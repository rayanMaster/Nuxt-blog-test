<script setup lang="ts">

</script>
<template>
  <PostList/>
</template>
