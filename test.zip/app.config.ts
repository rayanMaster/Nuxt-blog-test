export default defineAppConfig({
  seeds: {
    users: 1084,
    posts: 1084,
  },
});
